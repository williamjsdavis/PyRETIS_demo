MD flux simulation
==================

Simulation settings
-------------------
task = 'md-flux'
steps = 1000000
interfaces = [-0.9]
exe-path = '/content/TSI-1D-flux'
endcycle = 1000000

System settings
---------------
units = 'lj'
dimensions = 1
temperature = 0.07

Engine settings
---------------
class = 'Langevin'
timestep = 0.002
gamma = 0.3
high_friction = False
seed = 0

Particles settings
------------------
position = {'file': 'initial.xyz'}
velocity = {'generate': 'maxwell', 'momentum': False, 'seed': 0}
mass = {'Ar': 1.0}
name = ['Ar']
type = [0]
npart = 1

Forcefield settings
-------------------
description = '1D double well potential'

Potential
---------
class = 'DoubleWell'
a = 1.0
b = 2.0
c = 0.0

Orderparameter settings
-----------------------
class = 'Position'
dim = 'x'
index = 0
periodic = False
name = 'Order Parameter'

Output settings
---------------
backup = 'overwrite'
energy-file = 1000
order-file = 1000
cross-file = 1
trajectory-file = -1
pathensemble-file = 1
restart-file = 1
screen = 10

TIS settings
------------
allowmaxlength = False
aimless = True
high_accept = False
rescale_energy = False
seed = 0
shooting_move = 'sh'
shooting_moves = []
sigma_v = -1
zero_momentum = False

Analysis settings
-----------------
blockskip = 1
bins = 100
maxblock = 1000
maxordermsd = -1
ngrid = 1001
plot = {'output': 'png', 'plotter': 'mpl', 'style': 'pyretis'}
report = ['latex', 'rst', 'html']
skipcross = 1000
txt-output = 'txt.gz'